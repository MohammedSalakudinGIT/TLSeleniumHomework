package hooks;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.collections.Lists;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import utils.DataProviderExcelRead;
import wrappers.BaseDriver;

public class TestNgHooks extends BaseDriver{
	
	@BeforeSuite
	public void initalization()
	{
		
	}
	
	@BeforeTest
	public void setupTests()
	{
		
	}
	
	@BeforeClass
	public void beforeClassSteps()
	{
		
	}
	
	@BeforeMethod
	public void invoke()
	{
		startApp("chrome", "http://leaftaps.com/opentaps");
	}
	
	@AfterMethod
	public void close()
	{
		closeActiveBrowser();
	}
	
	@AfterClass
	public void afterClassSteps()
	{
	}
	
	@AfterTest
	public void completeTests()
	{
		
	}
	
	@DataProvider(name="FetchLoginData")
	public Object[][] readLoginExcelData(){
		try {
			return DataProviderExcelRead.readExcel("Login");
		} catch (InvalidFormatException e) {
			System.err.println("The excel file is invalid");
		} catch (IOException e) {
			System.err.println("The excel file does not exist");
		}
		return null;
	}
	
	@DataProvider(name="FetchCreateLead")
	public Object[][] readCreateLeadExcelData(){
		try {
			return DataProviderExcelRead.readExcel("CreateLead");
		} catch (InvalidFormatException e) {
			System.err.println("The excel file is invalid");
		} catch (IOException e) {
			System.err.println("The excel file does not exist");
		}
		return null;
	}
	
	
	@DataProvider(name="MergerDataProviders")
	public Object[][] dataProviderMerge(){
		
			  try {
				List<Object[]> result = Lists.newArrayList();	
				  result.addAll(Arrays.asList(readLoginExcelData()));
				  result.addAll(Arrays.asList(readCreateLeadExcelData()));
				  return result.toArray(new Object[result.size()][]);
			} catch (Exception e) {
				System.err.println("Merge Data provider not executed");
			}
		return null;
	}
	
	
	@Before
	public void initBefore()
	{
		invoke();
	}
	
	
	@After
	public void testAfter()
	{
		close();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
