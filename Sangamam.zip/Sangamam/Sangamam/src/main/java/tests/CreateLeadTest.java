package tests;


import org.testng.annotations.Test;

import hooks.TestNgHooks;
import pages.LoginPage;

public class CreateLeadTest extends TestNgHooks{
	
	@Test(dataProvider = "MergerDataProviders")
	public void createLeadTest(String Username, String Password, String companyName, String firstName,String lastName) {
		new LoginPage()
		.typeUserName(Username)
		.typePassword(Password)
		.clickLogin()
		.verifyLogin()
		.clickCRMSFA()
		.clickLeads()
		.clickCreateLead()
		.enterCompanyName(companyName)
		.enterFirstName(firstName)
		.enterLastName(lastName)
		.clickSubmit();
		
	}

}
	