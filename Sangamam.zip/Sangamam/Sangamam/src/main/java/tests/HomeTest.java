package tests;


import org.testng.annotations.Test;

import hooks.TestNgHooks;
import pages.LoginPage;

public class HomeTest extends TestNgHooks{
	
	@Test(dataProvider = "FetchLoginData")
	public void homeTest(String Username, String Password) {
		new LoginPage()
		.typeUserName(Username)
		.typePassword(Password)
		.clickLogin()
		.verifyLogin()
		.clickCRMSFA();
		
	}

}
	