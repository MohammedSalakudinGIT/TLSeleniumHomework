package tests;


import org.testng.annotations.Test;

import hooks.TestNgHooks;
import pages.LoginPage;

public class MyLeadsTest extends TestNgHooks{
	
	@Test(dataProvider = "FetchLoginData")
	public void myHomeTest(String Username, String Password) {
		new LoginPage()
		.typeUserName(Username)
		.typePassword(Password)
		.clickLogin()
		.verifyLogin()
		.clickCRMSFA()
		.clickLeads()
		.clickCreateLead();
		
	}

}
	