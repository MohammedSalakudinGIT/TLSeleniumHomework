package tests;


import org.testng.annotations.Test;

import hooks.TestNgHooks;
import pages.LoginPage;

public class LoginTest extends TestNgHooks{
	
	@Test(dataProvider = "FetchLoginData")
	public void loginTest(String Username, String Password) {
		new LoginPage()
		.typeUserName(Username)
		.typePassword(Password)
		.clickLogin();		
	}

}
	