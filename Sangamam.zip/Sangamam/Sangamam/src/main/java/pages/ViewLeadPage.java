package pages;

import hooks.TestNgHooks;
import io.cucumber.java.en.Then;

public class ViewLeadPage extends TestNgHooks{
	

	@Then("Verify new lead is created") 
	
	public void verifyIfLeadIsCreated() {
		
		verifyDisplayed(locateElement("id", "viewLead_companyName_sp"));
		
  }

}
