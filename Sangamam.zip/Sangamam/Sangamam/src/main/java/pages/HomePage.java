package pages;

import hooks.TestNgHooks;
import io.cucumber.java.en.And;

public class HomePage extends TestNgHooks{
	
	@And("Verify login is success")
	public HomePage verifyLogin() {
		verifyPartialText(locateElement("tag", "h2"), "Welcome");
		return new HomePage();
	}
	
	@And("Click CRMSFA") 
	public MyHomePage clickCRMSFA() {
	click(locateElement("link", "CRM/SFA"));
	return new MyHomePage();
	}

}
