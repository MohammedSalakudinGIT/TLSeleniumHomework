package pages;

import hooks.TestNgHooks;
import io.cucumber.java.en.And;

public class CreateLeadPage extends TestNgHooks{
	
	 @And("Enter Company Name as (.*)$") 
	  public CreateLeadPage enterCompanyName(String companyName) {
	  type(locateElement("id", "createLeadForm_companyName"), companyName);
	  return this;
	  }
	  
	  @And("Enter First Name as (.*)$") 
	  public CreateLeadPage enterFirstName(String firstName) {
	  type(locateElement("id", "createLeadForm_firstName"), firstName);
	  return this;
	  }
	  
	  @And("Enter Last Name as (.*)$") 
	  public CreateLeadPage enterLastName(String lastName) {
	  type(locateElement("id", "createLeadForm_lastName"), lastName);
	  return this;
	  }
	  
	  @And("Click Submit") 
	  public ViewLeadPage clickSubmit() {
	  click(locateElement("name", "submitButton"));
	  return new ViewLeadPage();
	  } 

}
