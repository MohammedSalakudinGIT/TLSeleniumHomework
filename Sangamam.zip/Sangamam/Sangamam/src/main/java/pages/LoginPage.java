package pages;

import hooks.TestNgHooks;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

public class LoginPage extends TestNgHooks{
	
	@When("Enter the username {string}")
	public LoginPage typeUserName(String userdata)
	{
		type(locateElement("id", "username"),userdata);
		return this;	
	}

	
	@And("Enter the password {string}")	
	public LoginPage typePassword(String passdata)
	{
		type(locateElement("id", "password"),passdata);
		return this;	
	}
	
	@And("Click Login button")
	public HomePage clickLogin() {
		click(locateElement("class", "decorativeSubmit"));
		return new HomePage();
	}

}
