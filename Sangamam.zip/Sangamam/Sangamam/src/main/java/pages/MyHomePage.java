package pages;

import hooks.TestNgHooks;
import io.cucumber.java.en.When;

public class MyHomePage extends TestNgHooks{
	
	@When("Click Leads")
	public MyLeadsPage clickLeads() {
		click(locateElement("link", "Leads"));
		return new MyLeadsPage();
	}
	
	
	
	
	
	

	
	
	
	
	
}
