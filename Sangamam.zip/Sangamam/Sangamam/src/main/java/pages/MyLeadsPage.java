package pages;

import hooks.TestNgHooks;
import io.cucumber.java.en.When;

public class MyLeadsPage extends TestNgHooks{
	
	@When("Click Create Leads") 
	public CreateLeadPage clickCreateLead() {
	click(locateElement("link", "Create Lead"));
	return new CreateLeadPage();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}
